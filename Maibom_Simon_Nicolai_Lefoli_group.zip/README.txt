If this line is too long, download Notepad++, GVim, Emacs, or similar.

Dear student,

I comment directly inline on your code and report. Search for the token OLEKS
to find my comments. Alongside the token is an integer indicator of the mood of
the comment. These are defined as follows:

< 0: Bad, e.g. room for improvement, mistake, or root of all evil.
= 0: Neutral, e.g. a stylistic comment, observation, or notice.
> 0: Good, e.g. slightly amused, impressed, or you made my day.

In practice, most comments lie in the range [-3;+1]. If you have any -2, or -3
comments, you are likely to be asked to resubmit, and those are exactly the
problems you should fix in your resubmission.

-- 
Happy hacking,
Oleks.

P.S. In your case, the comments on the report are here:

OLEKS -5: Where's your report? I want you to explain how you've modified the
grammar, how you've handled precedences, explain what works, what doesn't.
